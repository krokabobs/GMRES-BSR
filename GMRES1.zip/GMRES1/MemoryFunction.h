#ifndef GMRES_ILU0_MEMORYFUNCTION_H
#define GMRES_ILU0_MEMORYFUNCTION_H

template <typename T>
inline void DELETE_PTR(T **A){
  if (*A) delete *A;
  *A = nullptr;
}

template <typename T>
inline void DELETE_ARR(T **A){
  if (*A) delete[] *A;
  *A = nullptr;
}

template <typename T>
inline int ARR_ALLOCATION(T** A, int N){
  *A = new T [N];
  if (*A == nullptr)
    return -1;
  return 0;
}

template <typename T>
inline int ARR_REALLOCATION(T** A, int N){
  if (*A) delete[] *A;
  return ARR_ALLOCATION(A, N);
}


#endif //GMRES_ILU0_MEMORYFUNCTION_H
