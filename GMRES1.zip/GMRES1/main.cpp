//
// Created by Павел Филиппов on 10.12.2021.
//
#include "CSRmatrix.h"
#include "gmres.h"
#include <vector>

int main()
{
    CSRmatrix A;
    A.ReadMatrixFromFile ("/Users/pavelfilippov/Downloads/CSR/full0.mm", 3);
    int k = A.getMatrixSize()*A.getBlockSize();
    std::vector<double> result;
    result.resize(k);
    auto res = result.data();
    std::vector<double> vals = A.getVal();
    auto vals_ptr = vals.data();
    A.mv_prod(vals_ptr,res);
    //A.WriteMatrixToFile ("/Users/pavelfilippov/Downloads/CSR/res.mm");

    Gmres s(A);
   //vector<double> rhs (k, 0);
   //s.ReadRhs("/Users/pavelfilippov/Downloads/CSR/rhs0.mm", rhs, k);
    vector <double> sol (k,0);
    s.GMRES(sol);
    return 0;
}
