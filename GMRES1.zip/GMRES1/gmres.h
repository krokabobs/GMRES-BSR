//
// Created by Павел Филиппов on 13.12.2021.
//

#ifndef GMRES1_GMRES_H
#define GMRES1_GMRES_H
#include <cfloat>
#include <cstdint>
#include "CSRmatrix.h"
#include "matrix.h"
#include <vector>
using namespace std;

class Gmres {
public:
    double eps;
    Gmres(CSRmatrix &mtx);
    ~Gmres();
    int ReadRhs(const char *file_name, vector<double> &rhs, int size);
    //double norm (vector<double> &a);
    //void getKrylov(vector<vector<double>> &v, int j, vector<vector<double>> &h, int m);
    //vector<double> GMRES();
    void GMRES(std::vector<double>& sol);
private:
    CSRmatrix &mtx;
    int m;
};
#endif //GMRES1_GMRES_H
