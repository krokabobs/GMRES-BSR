#include "gmres.h"
#include <algorithm>
#include <cmath>
#include <vector>
#include <iostream>
#include "MatrixVectorTools.h"

using namespace std;

Gmres::Gmres(CSRmatrix &mtx) : mtx(mtx) {
    m = 300;
    eps = 1.e-5;
}

Gmres::~Gmres()= default;

int Gmres::ReadRhs(const char *file_name, vector<double> &rhs, int size){
    char buf[4096];
    int state = 0;
    int n = 0;
    char *start_ptr = nullptr, *end_ptr = nullptr;
    FILE *file = fopen(file_name, "r");
    if (!file){
        cout << "Error: Can't open file!\n";
        return -1;
    }
    int counter = 0;
    while (fgets(buf, 4096, file)) {
        if (state == 0){
            if (!strncmp(buf, "%%", 2))
                continue;
            start_ptr = buf;
            n = (int) strtol(start_ptr, &end_ptr, 10);
            if (start_ptr == end_ptr)
                continue;
            start_ptr = end_ptr;
            if (size != n){
                cout << "Error: Size of the rhs part doesn't match with matrix size!\n";
                return -1;
            }
            state = 1;
            continue;
        }
        else if (state == 1){
            start_ptr = buf;
            rhs[counter++] = strtod(start_ptr, &end_ptr);
        }
    }
    return 0;
}
/*
double Gmres::norm(vector<double> &a)
{
    double sumSqr = 0;
    for(int i = 0; i < a.size(); i++){
        sumSqr += a[i]*a[i];
    }
    return sqrt(sumSqr);
}
*/

//vector<vector<double>> v(n);
//for (int i = 0; i < n; i++){
//    v[i].resize(m);
//}

/*
vector<double> Gmres::GMRES() {
    vector<double> r0(m, 0), g (m+1, 0);
    vector<double> b (m, 0);
    vector<double> x0 (m, 0);
    ReadRhs("/Users/pavelfilippov/Downloads/CSR/rhs0.mm", b, m);
    g[0] = 1;
    vector<vector<double>> v(m+1, vector<double>(m, 0)), h(m, vector<double> (m+1, 0));
    double normr0 = 0;
    vector <double> R((m+2)*(m+1));
    // r0 = b-A*x0
    vector<double> r(x0.size(), 0);
    mtx.mv_prod(x0, r);
    for (int i = 0; i < r0.size(); i++) {
        r0[i] = b[i] - r[i];
        normr0 += r0[i] * r0[i];
    }
    // v1 = r0/||r0||
    normr0 = sqrt(normr0);
    for (int i = 0; i < r0.size(); i++) {
        r0[i] = r0[i] / normr0;
    }
    double* a;
    a = new double[v.size()];
    //for (int i = 0; i < v.size(); i++)
    //    a[i] = *v[i].data();
    auto b_ptr = r0.data();
    for (int i = 0; i < r0.size(); i++) {
        v[v.size()-1][i] = b_ptr[i];
    }
    //v.push_back(r0);
    // g = |r0|e1
    for(int i = 0; i < g.size(); i++){
        g[i] = normr0*g[i];
    }
    vector<double> cs(m+5, 0), sn(m+5, 0);
    for(int j = 0; j < m; j++){
        //getKrylov(v, j, h, m);
        vector<double> w(r0.size(),0);
        mtx.mv_prod(v[j], w);
        vector<double> h_colj;
        auto hc = h_colj.data();
        for (int i = 0; i <= j; i++) {
            for (int d = 0; d < v.size(); d++){
                hc[d] += (w[d])*(v[i][d]);
            }
            //h_colj.push_back(inner_product(w.begin(), w.end(), v[i].begin(), 0.0));
            for (int k = 0; k < w.size(); k++) {
                w[k] = w[k] - h_colj[i] * v[i][k];
            }
        }
        for (int s = 0; s < v.size() + w.size(); s++) {
            hc[v.size()+s] = norm(w);
        }
        //h_colj.push_back(norm(w));
        vector<double> v_next;
        auto vn = v_next.data();
        for (int l = 0; l < w.size(); l++) {
            vn[l] = w[l] / h_colj[j + 1];
            //v_next.push_back(w[l] / h_colj[j + 1]);
        }
        h_colj.resize(m + 1, 0);
        for (int p = 0; p < w.size() + r0.size() ; p++) {
            a[r0.size() + p] = vn[p];
        }
        //v.push_back(v_next);
        for(int k = 1; k <= j; k++){
            double tempPrev = cs[k-1]*h[j][k-1]+sn[k-1]*h[j][k];
            h[j][k] = -sn[k-1]*h[j][k-1]+cs[k-1]*h[j][k];
            h[j][k-1] = tempPrev;
        }
        double denom = sqrt(h[j][j]*h[j][j]+h[j][j+1]*h[j][j+1]);
        cs[j] = h[j][j]/denom;
        sn[j] = h[j][j+1]/denom;
        h[j][j] = denom;
        g[j+1] = -sn[j]*g[j];
        g[j] = cs[j]*g[j];
    }
    int n = (m+1)*(m+2);
    for(int i = 0; i < h.size(); i++){
        for(int j = 0; j < h[i].size(); j++){
            R[j*n+i] = h[i][j];
        }
    }
    //Ry = g
    vector<double> y(m, 0);
    for(int i = m-1; i >= 0; i--){
        double sum = 0;
        for(int j = m-1; j >= i+1; j--){
            sum += R[i*n+j] * y[j];
        }
        y[i] = (g[i]-sum)/R[i*n+i];
    }
    // xm = x0 + yk*vk
    vector<double> xm(x0.size(), 0);
    vector<double> sum(x0.size(), 0);
    for(int k = 0; k < m; k++){
        for(int i = 0; i < v[k].size(); i++){
            sum[i] += y[k]*v[k][i];
        }
    }
    for(int i = 0; i < x0.size(); i++){
        xm[i] = x0[i]+sum[i];
    }
    delete a;
    return xm;
}
*/

void Gmres::GMRES(std::vector<double>& sol) {
    int n_ = mtx.getMatrixSize();
    int bs = mtx.getBlockSize();
    auto n = n_ * bs;
    vector<double> rhs(n, 0);
    ReadRhs("/Users/pavelfilippov/Downloads/CSR/rhs0.mm", rhs, n);
    std::vector<double> H(m * (m + 1), 0.);
    std::vector<double> V(n * (m + 1));
    std::vector<double> cs(m + 1);
    std::vector<double> sn(m + 1);
    std::vector<double> g(m + 1, 0.);
    std::vector<double> r(n);
    std::vector<double> W(n);

    //std::vector<double> sol(n, 0.);

    auto r_norm = calc_norm(rhs.data(), n);

    int iter = 0;
    int max_iter = 1000;
    double tol = r_norm * eps;
    memcpy(r.data(), rhs.data(), n * sizeof(double));
    auto w = W.data();
    while (iter < max_iter) {
        iter++;
        g[0] = r_norm;
        auto beta_inv = 1 / r_norm;

        for (int i = 0; i < n; i++) {
            V[i] = r[i] * beta_inv;
        }
        int j = 0;
        for (j = 0; j < m; j++) {
            auto vj = V.data() + j * n;
            std::memset(w, 0., n * sizeof(double));

            mtx.mv_prod(vj, w);

            auto hj = H.data() + j * (m + 1);

            for (int i = 0; i < j; i++) {
                auto vi = V.data() + i * n;
                auto hji = vv_product(vi, w, n);
                hj[i] = hji;
                for (int k = 0; k < n; k++) {
                    w[k] -= hji * vi[k];
                }
            }
            auto w_norm = calc_norm(w, n);
            hj[j + 1] = w_norm;
            auto vj1 = vj + n;
            if (w_norm > std::numeric_limits<double>::epsilon()) {
                w_norm = 1 / w_norm;
                //sv_product(vj1, w_norm, n);
                for (int k = 0; k < n; k++) {
                    vj1[k] = w[k] * w_norm;
                }
            }
            //for (int i = 1; i <= m; i++){
            //    double temp = cs[i - 1]*hj[i-1] + sn[i - 1]*hj[i];
            //    hj[i] = -sn[i-1]*hj[i-1] + cs[i-1]*hj[i];
            //    hj[i - 1] = temp;
            //}

            for (int i = 0; i < j; i++) {
                auto tmp = hj[i];
                hj[i] = cs[i] * tmp + sn[i] * hj[i + 1];
                hj[i + 1] = -sn[i] * tmp + cs[i] * hj[i + 1];
            }
            auto den = std::sqrt(hj[j] * hj[j] + hj[j + 1] * hj[j + 1]);
            if (den < std::numeric_limits<double>::epsilon()) {
                den = std::numeric_limits<double>::epsilon();
            }
            cs[j] = hj[j] / den;
            sn[j] = hj[j + 1] / den;
            g[j + 1] = -sn[j] * g[j];
            g[j] *= cs[j];
            hj[j] = cs[j] * hj[j] + sn[j] * hj[j + 1];

            r_norm = fabs(g[j+1]);
            std::cout << "Current iteration: " << iter + 1 << " residual: " << r_norm << "\n";
            if (r_norm <= tol)
                break;
        }
        g[j] /= (H.data() + j * (m + 1))[j];
        for (int k = j - 1; k >= 0; k--) {
            auto tmp = g[k];
            for (int i = k + 1; i < j; i++) {
                tmp -= H[k + i * (m + 1)];
            }
            g[k] = tmp / H[k + k * (m + 1)];
        }
        std::memcpy(w, V.data(), n * sizeof(double));
        auto tmp = g[0];
        sv_product(w, tmp, n);
        for (int i = 0; i < j; i++) {
            auto cur_v = V.data() + i * n;
            auto tmp1 = g[i];
            vv_sum(w, tmp1, cur_v, n);
        }
        vv_sum(sol.data(), 1.0, w, n);
        if (r_norm < tol) {
            mtx.mv_prod(sol.data(), r.data());
            for (int i = 0; i < n; i++) {
                r[i] = rhs[i] - r[i];
            }
            r_norm = calc_norm(r.data(), n);
            if (r_norm < tol)
                break;
            else {
                memcpy(V.data(), r.data(), n*sizeof(double));
                j = 0;
                iter++;
            }
        }
    }
}



































